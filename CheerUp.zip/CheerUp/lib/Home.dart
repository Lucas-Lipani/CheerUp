import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List _itens = [];

  void _carregarItens(){
    _itens = [];
    for(int i=0; i<=30; i++){
      Map<String, dynamic> item = Map();
      item["titulo"] = "Titulo do Evento ${i} da lista";
      item["descricao"]="Descrição do Evento ${i} da lista - Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent semper dolor lorem, a bibendum ex aliquet eleifend. Fusce neque dui, imperdiet eu sagittis sit amet, vulputate non nisl. Nullam neque lacus, dignissim ac felis sed, faucibus rhoncus metus. Nunc maximus";
      _itens.add(item);
    }
  }

  @override
  Widget build(BuildContext context) {
    _carregarItens();
    return Scaffold(
      body: Container(
        padding: EdgeInsets.only(left: 5.0, top: 10.0, right: 5.0, bottom: 0.0),
        child: ListView.separated(
            separatorBuilder: (BuildContext context, int index) {
              return SizedBox(height: 7);
            },
            itemCount: _itens.length,
            itemBuilder: (context, indice) {
              //print("item ${indice}");
              //Map<String, dynamic> item =_itens[indice];
              //print("item ${_itens[indice]["titulo"]}");
              return Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(9),
                ),
                elevation: 5,
                shadowColor: Colors.grey,
                child: ListTile(
                      onTap: (){
                        //print("Clique com onTap ${indice}");
                        showDialog(
                            context: context,
                            builder: (context){
                              return AlertDialog(
                                title: Text(_itens[indice]["titulo"]),
                                titleTextStyle: TextStyle(
                                  fontSize: 20,
                                ),
                                content: Text(_itens[indice]["descricao"]),
                                actions: <Widget>[ //definir widgets
                                  TextButton(
                                      onPressed: (){
                                        //print("Selecionado sim");
                                        Navigator.pop(context);
                                      },
                                      style: TextButton.styleFrom(
                                        backgroundColor: Colors.greenAccent,
                                        primary: Colors.white,
                                      ),
                                      child: Text("Up")
                                  ),
                                  TextButton(
                                      onPressed: (){
                                        //print("Selecionado não");
                                        Navigator.pop(context);
                                      },
                                      style: TextButton.styleFrom(
                                        backgroundColor: Colors.red,
                                        primary: Colors.white,
                                      ),
                                      child: Text("Down")
                                  ),
                                ],
                              );
                            }
                        );
                      },
                      onLongPress: (){
                        //print("Clique com onLongPress ${indice}");
                      },

                      title: Text(_itens[indice]["titulo"], style: TextStyle(fontSize: 18)),
                      subtitle: Text(_itens[indice]["descricao"]),
                    ),
                );
            }
        ),
      ),
    );
  }
}
