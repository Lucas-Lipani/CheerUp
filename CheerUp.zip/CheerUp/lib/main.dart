import "package:flutter/material.dart";

import 'Perfil.dart';
import 'Home.dart';
import 'Sobre.dart';
import 'Cadastro.dart';
import 'CadastroUsuario.dart';
import 'Login.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Login(),
  ));
}

class Inicio extends StatefulWidget {
  @override
  _InicioState createState() => _InicioState();
}

class _InicioState extends State<Inicio> {
  int _indiceAtual = 0;
  String titulo = "Cheer UP";

  final List<Widget> _telas = [
    Home(),
    Cadastro(),
    Perfil(),
    Sobre()
  ];

  void onTabTapped(int index) {
    setState(() {
      _indiceAtual = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(titulo),
      ),
      body: _telas[_indiceAtual],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _indiceAtual,
        unselectedItemColor: Colors.white,
        selectedItemColor: Colors.blue,
        onTap: onTabTapped,
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: "Início",
              backgroundColor: Colors.black),
          BottomNavigationBarItem(
              icon: Icon(Icons.add_circle),
              label: "Cadastro",
              backgroundColor: Colors.black),
          BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: "Perfil",
              backgroundColor: Colors.black),
          BottomNavigationBarItem(
              icon: Icon(Icons.info),
              label: "Sobre",
              backgroundColor: Colors.black),
        ],
      ),
    );
  }
}
/*
class Home extends StatelessWidget {
  final String texto;

  Home(this.texto);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text("Publicação 1"),
      ),
    );
  }
}
*/


