import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'Banco.dart';
import 'main.dart';

class Home extends StatefulWidget {
  String id_usuario;

  Home(this.id_usuario);

  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List itens = [];
  String campo = 'votos_evento';
  String ordem = 'DESC';
  String evento_tudo;

  _buscarEventos(String campo,String ordem) async{
    Database bd = await Banco.recuperarBancoDados();
    String sql = "SELECT * FROM tbevento ORDER BY "+ campo + " " + ordem + ";";
    List<Map> result = await bd.rawQuery(sql); //conseguimos escrever a query que quisermos

    result.forEach((row) => print(row));

    for(var usu in result){
      Map<String, dynamic> item = Map();

      item["titulo"] = usu['nome_evento'];
      item["descricao"] = usu['descricao_evento'];
      item["texto_evento"] = "Descrição: " + usu['descricao_evento'] +
          "\nHora Evento: " + usu['hora_evento'] +
          "\nLocal Evento: " + usu['local_evento'].toString() +
          "\nVotos do Evento: " + usu['votos_evento'].toString();
          //item["descricao"]="Descrição do Evento ${i} da lista - Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent semper dolor lorem, a bibendum ex aliquet eleifend. Fusce neque dui, imperdiet eu sagittis sit amet, vulputate non nisl. Nullam neque lacus, dignissim ac felis sed, faucibus rhoncus metus. Nunc maximus";
      itens.add(item);
    }
    print(itens.length);
  }

  _upVoteEvento(String nome, String descricao) async{
    print(nome);
    print(descricao);

    Database bd = await Banco.recuperarBancoDados();
    String sql = "SELECT * FROM tbevento WHERE nome_evento = '" + nome + "' AND descricao_evento = '" + descricao + "';";
    List<Map> result = await bd.rawQuery(sql); //conseguimos escrever a query que quisermos

    //result.forEach((row) => print(row));
    int votos;

    for(var usu in result){
      Map<String, dynamic> item = Map();
      votos = usu['votos_evento'] + 1;
      itens.add(item);
    }
    print(itens.length);
    print("votos: " + votos.toString());

    String sql2 = "UPDATE tbevento SET votos_evento = "+ votos.toString() +" WHERE nome_evento = '" + nome + "' AND descricao_evento = '" + descricao + "';";
    await bd.rawQuery(sql2);
  }

  _downVoteEvento(String nome, String descricao) async{
    print(nome);
    print(descricao);

    int votos;

    Database bd = await Banco.recuperarBancoDados();
    String sql = "SELECT * FROM tbevento WHERE nome_evento = '" + nome + "' AND descricao_evento = '" + descricao + "';";
    List<Map> result = await bd.rawQuery(sql); //conseguimos escrever a query que quisermos

    //result.forEach((row) => print(row));

    for(var usu in result){
      Map<String, dynamic> item = Map();
      votos = usu['votos_evento'] - 1;
      itens.add(item);
    }
    print(itens.length);
    print("votos: " + votos.toString());

    String sql2 = "UPDATE tbevento SET votos_evento = "+ votos.toString() +" WHERE nome_evento = '" + nome + "' AND descricao_evento = '" + descricao + "';";
    await bd.rawQuery(sql2);
  }

  @override
  Widget build(BuildContext context) {
    print("Chegou home id: "+ (widget.id_usuario));
    // Initial Selected Value

    //getIdUsuario.setID(widget.id_usuario);


    //_buscarEventos();

    return FutureBuilder(

      future: _buscarEventos('votos_evento','DESC'),
      builder: (BuildContext context, AsyncSnapshot snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) {
        return CircularProgressIndicator();
      }

      if (snapshot.hasData) {
        return Text(snapshot.data);
      }

      return Scaffold(
        body: Container(
          padding: EdgeInsets.only(
              left: 5.0, top: 10.0, right: 5.0, bottom: 0.0),
          child: ListView.separated(
              separatorBuilder: (BuildContext context, int index) {
                return SizedBox(height: 7);
              },
              itemCount: itens.length,
              itemBuilder: (context, indice) {
                //print("item ${indice}");
                //Map<String, dynamic> item =_itens[indice];
                //print("item ${_itens[indice]["titulo"]}");
                return Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(9),
                  ),
                  elevation: 5,
                  shadowColor: Colors.grey,
                  child: ListTile(
                    onTap: () {
                      //print("Clique com onTap ${indice}");
                      showDialog(
                          context: context,
                          builder: (context) {
                            return AlertDialog(
                              title: Text(itens[indice]["titulo"]),
                              titleTextStyle: TextStyle(
                                fontSize: 20,
                                color: Colors.black
                              ),

                              content: Text(itens[indice]["texto_evento"]),
                              actions: <Widget>[ //definir widgets
                              //ToDo: Mostrar os votos de um evento nos cards
                                TextButton(
                                    onPressed: () {
                                      _downVoteEvento(itens[indice]["titulo"].toString(), itens[indice]["descricao"].toString());
                                      Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(builder: (context) => Inicio(widget.id_usuario)),
                                      );
                                    },
                                    style: TextButton.styleFrom(
                                      backgroundColor: Colors.red,
                                      primary: Colors.white,
                                    ),
                                    child: Text("Down")
                                ),
                                TextButton(
                                    onPressed: () {
                                      _upVoteEvento(itens[indice]["titulo"].toString(), itens[indice]["descricao"].toString());
                                      Navigator.pop(context);
                                      Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(builder: (context) => Inicio(widget.id_usuario)),
                                      );
                                    },
                                    style: TextButton.styleFrom(
                                      backgroundColor: Colors.greenAccent,
                                      primary: Colors.white,
                                    ),
                                    child: Text("Up")
                                ),
                              ],
                            );
                          }
                      );
                    },
                    title: Text(itens[indice]["titulo"], style: TextStyle(fontSize: 18)),
                    subtitle: Text(itens[indice]["descricao"]),
                  ),
                );
              }
          ),
        ),
      );
      },
    );

  }
}
