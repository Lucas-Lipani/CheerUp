import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:navegacao/utilities/constants.dart';
import 'main.dart';
import 'Login.dart';

class Banco {

  static recuperarBancoDados() async {
    final caminhoBancoDados = await getDatabasesPath();
    final localBancoDados = join(caminhoBancoDados, "banco.bd");
    var bd = await openDatabase(
        localBancoDados,
        version: 1,
        onCreate: (db, banco) async {
          await db.execute(
              "CREATE TABLE tbusuario (id INTEGER PRIMARY KEY AUTOINCREMENT, nome_usuario VARCHAR, email_usuario VARCHAR, senha_usuario VARCHAR, sobre_usuario VARCHAR);");
          await db.execute(
              "CREATE TABLE tbevento (id INTEGER PRIMARY KEY AUTOINCREMENT, nome_evento VARCHAR, descricao_evento VARCHAR, local_evento VARCHAR, hora_evento VARCHAR, votos_evento INTEGER, id_usuario INTEGER, FOREIGN KEY(id_usuario) REFERENCES tbusuario(id));");
          /*
            String sql1 = "CREATE TABLE tbusuario (id INTEGER PRIMARY KEY AUTOINCREMENT, nome_usuario VARCHAR, email_usuario VARCHAR, senha_usuario VARCHAR);";
            db.execute(sql1);
            String sql2 = "CREATE TABLE tbevento (id INTEGER PRIMARY KEY AUTOINCREMENT, nome_evento VARCHAR, descricao_evento VARCHAR, local_evento VARCHAR, hora_evento VARCHAR, id_usuario INTEGER);";
            db.execute(sql2);*/
        }
    );
    return bd;
  }

}