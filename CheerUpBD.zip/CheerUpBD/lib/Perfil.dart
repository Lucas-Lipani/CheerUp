import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:navegacao/utilities/constants.dart';
import 'package:sqflite/sqflite.dart';
import 'Banco.dart';

class Perfil extends StatefulWidget {
  String id_usuario;

  Perfil(this.id_usuario);

  @override
  _PerfilState createState() => _PerfilState();
}

class _PerfilState extends State<Perfil> {

  String email;
  String nome;
  String sobre;

  TextEditingController _textoDeEntradaSobre = TextEditingController();

  _consultaUsuario() async {
    Database bd = await Banco.recuperarBancoDados();
    String sql2 = "SELECT * FROM tbusuario WHERE id = '" + widget.id_usuario + "';";
    List eventos2 = await bd.rawQuery(sql2);

    for(var usu in eventos2){
        email = usu['email_usuario'].toString();
        nome = usu['nome_usuario'].toString();
        sobre = usu['sobre_usuario'].toString();
    }
    print(sobre);
  }


  Widget _buildFotoPerfilRow() {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 30.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          _buildFotoBtn(
                () => print('Login with Facebook'),
            AssetImage(
              'assets/logos/facebook.jpg',
            ),
          ),
        ],
      ),
    );
  }

  Widget buildAbout() => Container(
    padding: EdgeInsets.symmetric(horizontal: 48),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Sobre',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'OpenSans',
            fontSize: 30.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 3),
        Card(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(9),
            side: BorderSide(color: Colors.white, width: 1),

          ),
          elevation: 0,
          shadowColor: Colors.grey,
          color: Colors.transparent,

          child: Padding(
            padding: EdgeInsets.fromLTRB(8, 5, 8, 5),
            child: Text(
              sobre.toString(),
              //style: TextStyle(fontSize: 16, height: 1.4, color: Colors.white),
              style: kLabelStyle,
            )
          ),
        ),
      ],
    ),
  );

  // void initState() {
  //   super.initState();
  //   Timer(const Duration(seconds: 1), () {
  //     Navigator.push(
  //       context,
  //       MaterialPageRoute(builder: (context) => Perfil(widget.id_usuario)),
  //     );
  //   });
  // }

  _displayTextInputDialog(BuildContext context) {
    return showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Insira um breve texto sobre você'),
          content: TextField(
            controller: _textoDeEntradaSobre,
            decoration: InputDecoration(hintText: "Escreva aqui."),
          ),
          actions: <Widget>[
            FlatButton(
              child: Text('CANCEL'),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            FlatButton(
              child: Text('INSERIR'),
              onPressed: () {
                setState(() { sobre = _textoDeEntradaSobre.text; });
                print(_textoDeEntradaSobre.text);
                Navigator.pop(context);
                if(_textoDeEntradaSobre.text.isNotEmpty){
                  print("Entrou no if");
                  _updateSobre(widget.id_usuario, _textoDeEntradaSobre.text);

                  // initState();
                }
                else{
                  print("não entrou no if");
                }
              },
            ),
          ],
        );
      },
    );
  }

  _updateSobre(String id, String sobre) async{
    Database bd = await Banco.recuperarBancoDados();
    String sql = "UPDATE tbusuario SET sobre_usuario = '"+ sobre +"' WHERE id = " + id + ";";
    await bd.rawQuery(sql);

    String sql2 = "SELECT * FROM tbusuario;";
    List<Map> result = await bd.rawQuery(sql2);
    result.forEach((row) => print(row));
    _consultaUsuario();

  }




  Widget _buildSobreBtn() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25.0),
      width: double.infinity,
      child: RaisedButton(
        elevation: 5.0,

        onPressed: () {

          _displayTextInputDialog(context);
          buildAbout();
        },
        padding: EdgeInsets.all(15.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        color: Colors.white,
        child: Text(
          'Edite seu sobre',
          style: TextStyle(
            color: Color(0xFF527DAA),
            letterSpacing: 1.5,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'OpenSans',
          ),
        ),
      ),
    );
  }

  Widget _buildEmailText() {
    return Column(
      children: <Widget>[
        SizedBox(height: 20.0),
        Text(
          email.toString(),
          style: kLabelStyle,
        ),
      ],
    );
  }

  Widget _buildFotoBtn(Function onTap, AssetImage logo) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 130.0,
        width: 130.0,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              offset: Offset(0, 2),
              blurRadius: 6.0,
            ),
          ],
          image: DecorationImage(
            image: logo,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    print("Chegou o id de usuario:" + widget.id_usuario);

    return FutureBuilder(
      future: _consultaUsuario(),
      builder: (BuildContext context, AsyncSnapshot snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return CircularProgressIndicator();
        }

        if (snapshot.hasData) {
          return Text(snapshot.data);
        }

        return Scaffold(
          // appBar: AppBar(
          //   title: Text("perfil"),
          // ),
          body: AnnotatedRegion<SystemUiOverlayStyle>(
            value: SystemUiOverlayStyle.light,
            child: GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: Stack(
                children: <Widget>[
                  Container(
                    height: double.infinity,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0xFF73AEF5),
                          Color(0xFF61A4F1),
                          Color(0xFF478DE0),
                          Color(0xFF398AE5),
                        ],
                        stops: [0.1, 0.4, 0.7, 0.9],
                      ),
                    ),
                  ),
                  Container(
                    height: double.infinity,
                    child: SingleChildScrollView(
                      physics: AlwaysScrollableScrollPhysics(),
                      padding: EdgeInsets.symmetric(
                        horizontal: 40.0,
                        vertical: 40.0,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          _buildFotoPerfilRow(),
                          Text(
                            nome.toString(),
                            style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'OpenSans',
                              fontSize: 30.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          _buildEmailText(),
                          SizedBox(height: 30.0),
                          buildAbout(),
                          SizedBox(height: 30.0,),
                          _buildSobreBtn()
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        );
      },
    );

  }
}